

## How to set up?

1) Install pytorch by 

conda install pytorch=0.4.0 -c pytorch

2) Download the environment from one of the links below.  You need only select the environment that matches your operating system:

    - **_Version 2: Twenty (20) Agents_**
        - Linux: [click here](https://s3-us-west-1.amazonaws.com/udacity-drlnd/P2/Reacher/Reacher_Linux.zip)
        - Mac OSX: [click here](https://s3-us-west-1.amazonaws.com/udacity-drlnd/P2/Reacher/Reacher.app.zip)
        - Windows (32-bit): [click here](https://s3-us-west-1.amazonaws.com/udacity-drlnd/P2/Reacher/Reacher_Windows_x86.zip)
        - Windows (64-bit): [click here](https://s3-us-west-1.amazonaws.com/udacity-drlnd/P2/Reacher/Reacher_Windows_x86_64.zip)
    
    (_For Windows users_) Check out [this link](https://support.microsoft.com/en-us/help/827218/how-to-determine-whether-a-computer-is-running-a-32-bit-version-or-64) if you need help with determining if your computer is running a 32-bit version or 64-bit version of the Windows operating system.

    (_For AWS_) If you'd like to train the agent on AWS (and have not [enabled a virtual screen](https://github.com/Unity-Technologies/ml-agents/blob/master/docs/Training-on-Amazon-Web-Service.md)), then please use [this link](https://s3-us-west-1.amazonaws.com/udacity-drlnd/P2/Reacher/one_agent/Reacher_Linux_NoVis.zip) (version 1) or [this link](https://s3-us-west-1.amazonaws.com/udacity-drlnd/P2/Reacher/Reacher_Linux_NoVis.zip) (version 2) to obtain the "headless" version of the environment.  You will **not** be able to watch the agent without enabling a virtual screen, but you will be able to train the agent.  (_To watch the agent, you should follow the instructions to [enable a virtual screen](https://github.com/Unity-Technologies/ml-agents/blob/master/docs/Training-on-Amazon-Web-Service.md), and then download the environment for the **Linux** operating system above._)

3) Place the files in the directory of GitHub repository files

4) Run the Report.ipynb file and follow the instructions



#### The environment considered solved if each agent mean is above 30.0

## Description of the model architectures for any neural networks as per rubric

The most important component is a method learn:
Describing the class agent implementation 
Firstly I have initialised the actors and the optimizers here I have used adam optimizer

self.actor_local = Actor(state_size, action_size, random_seed).to(device)
self.actor_target = Actor(state_size, action_size, random_seed).to(device)
self.actor_optimizer = optim.Adam(self.actor_local.parameters(), lr=LR_ACTOR)

Then instialising the critic class and adam optimizer

self.critic_local = Critic(state_size, action_size, random_seed).to(device)
self.critic_target = Critic(state_size, action_size, random_seed).to(device)
self.critic_optimizer = optim.Adam(self.critic_local.parameters(), lr=LR_CRITIC, weight_decay=WEIGHT_DECAY)

Target actions
actions_next = self.actor_target(next_states)

Targer Q values
Q_targets_next = self.critic_target(next_states, actions_next) 

Fetching the target Q values with recent updated ones.
Q_targets = rewards + (gamma * Q_targets_next * (1 - dones)) 

Fetching current q value
Q_expected = self.critic_local(states, actions) 

Loss function 
critic_loss = F.mse_loss(Q_expected, Q_targets) 

Fetching current actions
actions_pred = self.actor_local(states) 

Incresing Q values using gradient ascent
actor_loss = -self.critic_local(states, actions_pred).mean() 

Making target closer to local with coefficient TAU.

self.soft_update(self.critic_local, self.critic_target, TAU)
self.soft_update(self.actor_local, self.actor_target, TAU)
self.epsilon -= self.epsilon_decay - decreasing exploration exploitation rate.

# Contiunous Control -DRLND P3


#Environment

Download the unity agents for according to your OS 

We have to download and run the .exe files from unity environments
Give the path where its downloaded and kept - Mac:
"path/to/Tennis.app"
-
Windows
(x86):
"path/to/Tennis_Windows_x86/Tennis.exe"
-
Windows
(x86_64):
"path/to/Tennis_Windows_x86_64/Tennis.exe"
-
Linux
(x86):
"path/to/Tennis_Linux/Tennis.x86" - Linux (x86_64): "path/to/Tennis_Linux/Tennis.x86_64"
- Linux (x86, headless): "path/to/Tennis_Linux_NoVis/Tennis.x86" - Linux (x86_64, headless):
"path/to/Tennis_Linux_NoVis/Tennis.x86_64"

## Requirements

* python 3
* pytorch 
* unityagent 
* Jupyter
* Numpy
* Matplotlib
* Tennis Unity Environment 


## How to run

1. Download the environment and unzip it into the directory of the project. Rename the folder to Tennis and ensure that it contains Tennis.exe 
2. Use jupyter to run the Report.ipynb notebook
3. To train the agent run the cells in order. They will initialize the environment and train until it reaches the goal condition of +0.5 average over 100 episode
4. A graph of the scores during training will be displayed after training. 

## Code

The code is split between three files namely agent.py containing the code for agent , model.py contains code for the model architecture of actor and critics an lastly replay_buffer.py which is used by agents to store their experinces and Report.ipynb for demo of the agent working.


